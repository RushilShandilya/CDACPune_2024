#include<iostream>
#include"complex.h"

int main(){
	
	Complex complexNumber;
	complexNumber.AcceptData();
	complexNumber.DisplayData();

	return 0;
}
