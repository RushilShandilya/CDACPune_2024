v = 10
console.log(`dsadas ${v}`)