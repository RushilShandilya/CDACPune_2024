class Window{
//properties
//method

    Document document;
}

class Document{

var s = new String("hello");
 var s = new String("hello");
    //properties
    //methods
}

Window window = new Window()
window.document.